class ReviewRunner {
  public static void main(String[] args) 
  {
    /* your code here, for example: */
    System.out.println(Review.fakeReview("C:\\Users\\1961680\\Desktop\\CSA\\Unit 2\\2.1\\2.1.6\\CSA_216_ConsumerLab_Starter\\ConsumerLab_Code\\reviewSample.txt"));
  }
}